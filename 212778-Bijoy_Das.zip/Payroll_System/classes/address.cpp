#include "address.h"

address::address(const string& i_door, const string& i_street, const string& i_area, 
     const string& i_city, const string& i_pincode) : door_number {i_door},
     street {i_street},  area {i_area}, city {i_city}, pincode {i_pincode} 
     {

     }

// getters for the class
string address::get_door() {
    return door_number;
}

string address::get_street() {
    return street;
}

string address::get_area() {
    return area;
}

string address::get_city() {
    return city;
}

string address::get_pincode() {
    return pincode;
}

// setters for the class 

void address::set_door(const string& door_) {
    door_number = door_;
}

void address::set_street(const string& street_) {
    street = street_;
}

void address::set_area(const string& area_) {
    area = area_;
}

void address::set_city(const string& city_) {
    city = city_;
}

void address::set_pin(const string& pincode_) {
    pincode = pincode_;
}

// address generator

string address::generate_address() {
    return get_door() + ", " + get_street() + ", " + get_area() + ", " + get_city() + ", " + get_pincode();
}
