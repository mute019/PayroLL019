#include <iostream>
#include <string>

using namespace std;

#ifndef ADDRESS_H
#define ADDRESS_H
class address {
    string door_number;
    string street;
    string area;
    string city;
    string pincode;

public:
    address(const string&, const string&, const string&, const string&, const string&);

private:
    string get_door();

    string get_street();

    string get_area();

    string get_city();

    string get_pincode();

    void set_door(const string& door_);

    void set_street(const string& street_);

    void set_area(const string& area_);

    void set_city(const string& city_);

    void set_pin(const string& pincode_);

public:
    string generate_address();
};

#endif
