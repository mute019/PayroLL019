#include "employee.h"

int employee::employee_id = 1245;

employee::employee(string& i_name, string& i_gender, address* i_adrs, string& i_location, string i_department,
                    string& i_employee_type, string& i_band, string& i_pf_no, string& i_bank, float& i_ctc)
                : f_name {i_name}, gender {i_gender}, adrs {i_adrs}, location {i_location}, department {i_department},
                employee_type {i_employee_type}, band {i_band}, pf_number {i_pf_no}, bank_acc {i_bank} , ctc {i_ctc}
                {
                    employee_id++;
                    e_id = employee_id; // e_id is being initialised with employee_id.
                }

string employee::get_name() {
    return f_name;
}
void employee::set_name(const string& name) {
    f_name = name;
}

string employee::get_gender() {
    return gender;
}

void employee::set_gender(const string& new_gender) {
    gender = new_gender;
}

address* employee::get_address() {
    return adrs;
}

string employee::get_location() {
    return location;
}


void employee::set_location(const string& new_location) {
    location = new_location;
}

// void employee::set_address(address& addrs) {
//     adrs = addrs;
// }

string employee::get_department() {
    return department;
}

void employee::set_department(const std::string& dept) {
    department = dept;
}


//void set_pass(const std::string& );

string employee::get_employee_type() {
    return employee_type;
}

void employee::set_employee_type(const string& type_) {
    employee_type = type_;
}

string employee::get_band() {
    return band;
}
void employee::set_band(const std::string& band_code) {
    band = band_code;
}

string employee::get_pf() {
    return pf_number;
}

void employee::set_pf(const string& pf_code) {
    pf_number = pf_code;
}

string employee::get_account() {
    return bank_acc;
}

void employee::set_account(const string& new_bank) {
    bank_acc = new_bank;
}

float employee::get_CTC() {
    return ctc;
}

void employee::set_CTC(const float& new_ctc) {
    ctc = new_ctc;
}

salary_slip* employee::get_slip(const string& key) {
    //salary_slip* ex_slip = slip_list[key]; 
    return slip_list[key];
}

void employee::push_slip(salary_slip* new_slp, const string& date_key) {
    slip_list[date_key] = new_slp;
}

void employee::push_slip(salary_slip* new_slp) {
    const string& date_key = (new util_())->get_date();
    slip_list[date_key] = new_slp;
}






