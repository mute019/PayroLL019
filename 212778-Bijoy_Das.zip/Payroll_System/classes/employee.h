#include <string>
#include <vector>
#include <map>
#include "address.h"
#include "salary_slip.h"
#include "util_.h"


#ifndef EMPLOYEE_H
#define EMPLOYEE_H

using namespace std;

class employee {

    string f_name;
    string gender;
    address *adrs;
    string location;
    static int employee_id;
    int e_id; // private variable for Employee ID fixed.
    string department;
    string employee_type;
    string band;
    string pf_number;
    string bank_acc;
    float ctc;
    map<string, salary_slip*> slip_list;

public:
    employee(string&, string&, address*, string&, string, string&,
    string&, string&, string& ,float& );

    string get_name();
    void set_name(const string& );

    string get_gender();
    void set_gender(const string& );

    address* get_address();

    string get_location();
    void set_location(const string& );

    string get_department();
    void set_department(const string&);

    string get_employee_type();
    void set_employee_type(const string& );

    string get_band();
    void set_band(const string& );
    
    string get_pf();
    void set_pf(const string& );

    string get_account();
    void set_account(const string& );

    int get_id() {
        return e_id;
    }

    float get_CTC();
    void set_CTC(const float& );

    map<string ,salary_slip*> get_slips();

    salary_slip* get_slip(const string& );

    void push_slip(salary_slip* , const string& );
    void push_slip(salary_slip*);
};

#endif
