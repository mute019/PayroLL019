#include "employer.h"
#include <utility>
#include "salary_slip.h"

employer::employer(const string& name, const vector<string>& location_list,
     const vector<string>& band_list, vector<string>& depart_list) : company_name {name}, location {location_list},
     bands {band_list}, departments {depart_list} 
      {

}

void employer::push_changes_CTC(float& value, const string& key) {
    emp_list[key]->set_CTC(value);
}

void employer::push_changes_name(string& value, const string& key) {
    emp_list[key]->set_name(value);
}

void employer::push_changes_loc(string& value, const string& key) {
    emp_list[key]->set_location(value);
}

void employer::push_changes_dept(string& value, const string& key) {
    emp_list[key]->set_department(value);
}   

void employer::push_changes_em_type(string& value, const string& key) {
    emp_list[key]->set_employee_type(value);
}   

void employer::push_changes_band(string& value, const string& key) {
    emp_list[key]->set_band(value);
}

void employer::push_changes_pf(string& value, const string& key) {
    emp_list[key]->set_pf(value);
}

void employer::push_changes_gender(string& value, const string& key) {
    emp_list[key]->set_gender(value);
}

void employer::push_changes_account(string& value, const string& key) {
    emp_list[key]->set_account(value);
}

void employer::modify_user(const string& key) {
    auto list = get_emp_list();

    if (list.find(key) == list.end()) {
        cout << "\n\nEmployee not found!!\n";
    } else {
        cout << "\n\n Change Menu.";
        cout << " \n 1. Employee Name" ;
        cout << " \n 2. Employee Gender " ;
        cout << " \n 3. Employee Location" ;
        cout << " \n 4. Employee Department " ;
        cout << " \n 5. Employee Band " ;
        cout << " \n 6. Employee PF_number " ;
        cout << " \n 7. Employee Bank Account Number " ;
        cout << " \n 8. Employee CTC \n";
        int choice;
        cout << "Enter Your Choice: ";
        cin >> choice;
        
        switch(choice) {    
            case 1: {
                string value;
                cout << "\n Enter New Name: ";
                cin.ignore();
                getline(cin, value);
                push_changes_name(value, key);
                break;
            } 
            case 2: {
                string value;
                cout << "\n Enter New Gender: ";
                cin >> value;
                push_changes_gender(value, key);
                break;
            }
            case 3: {
                string value;
                cout << "\n Enter New Location: ";
                cin >> value;
                push_changes_loc(value, key);
                break;
            }
            case 4: {
                string value;
                cout << "\n Enter New Department: ";
                cin >> value;
                push_changes_dept(value, key);
                break;
            }
            case 5: {
                string value;
                cout << "\n Enter New Band: ";
                cin >> value;
                push_changes_band(value, key);
                break;
            }
            case 6: {
                string value;
                cout << "\n Enter New PF_number: ";
                cin >> value;
                push_changes_pf(value, key);
                break;
            }
            case 7: {
                string value;
                cout << "\n Enter New Bank Account: ";
                cin >> value;
                push_changes_account(value, key);
                break;
            }
            case 8: {
                float value;
                cout << "\n Enter New CTC: "; // Changed the statement from "Enter New Gender" (This was the actually) to "Enter New CTC"
                
                cin >> value;
                push_changes_CTC(value, key);
                break;
            }
            default: cout << "\n\nWrong Choice!! \n Try Again!!\n\n";

        }
    }

}

void employer::generate_slip(const string& key) {
    auto list = get_emp_list();
    if (list.find(key) == list.end()) {
        cout << "\n\nEmployee not found!!\n";
    } else {
        float mess_bill;
        std::cout << "\n\n Enter Mess Bill: ";
        cin >> mess_bill;

        string date;
        std::cout << "\n\n Enter Date(mm-yyyy):";
        cin.ignore();
        getline(cin, date);

        salary_slip *slip = new salary_slip(list[key]->get_CTC(), mess_bill);
        if (date.empty()) {
            list[key]->push_slip(slip);
            slip->print_slip();
        } else {
            list[key]->push_slip(slip, date);
            slip->print_slip();
        }
    }
}


void employer::print_all() {
    auto list = get_emp_list();

    if (list.empty()) {
        cout << "\nEmployee list is empty!! \n";
    }

    for(auto& emp : list) {

        print_emp_details(emp.first);

        cout << endl << endl;
    }
}

void employer::print_emp_details(const string& key) {
    auto emp = get_emp_list()[key];
    cout << " \n Employee Name :" << emp->get_name();
    cout << " \n Employee Gender :" << emp->get_gender();
    cout << " \n Employee Address :" << emp->get_address()->generate_address();
    cout << " \n Employee Location:" << emp->get_location();
    cout << " \n Employee ID: " << key;
    cout << " \n Employee Department: " << emp->get_department();
    cout << " \n Employee Band: " << emp->get_band();
    cout << " \n Employee PF_number: " << emp->get_pf();
    cout << " \n Employee Bank Account Number: " << emp->get_account();
    cout << " \n Employee CTC: " << emp->get_CTC();

    cout << endl;

}   

void employer::search_employee(const string& key) {
    auto list = get_emp_list();
    if (list.find(key) != list.end()) {
        print_emp_details(key);
    } else {
        cout << "\n\nEmployee not found!!\n";
    }
}

void employer::remove_employee(const string& key) {
    
    if (emp_list.find(key) != emp_list.end()) {
        emp_list.erase(key);
    } else {
        cout << "\n\nEmployee not found!!\n";
    }
}

void employer::add_user() {
    string name;
    cout << "\nEnter Employee Name: ";
    getline(cin, name);

    string gender;
    cout << "\nEnter Gender: ";
    getline(cin, gender);

    string build_no;
    cout << "\nEnter Building No. :";
    getline(cin, build_no);

    string street;
    cout << "\nEnter Street No. :";
    getline(cin, street);

    string area;
    cout << "\nEnter Area : ";
    getline(cin, area);

    string city;
    cout << "\nEnter City : ";
    getline(cin, city);

    string pin;
    cout << "\nEnter Pincode: ";
    getline(cin, pin);

    string location;
    cout << "\nEnter location: ";
    getline(cin, location);

    string department;
    cout << "\nEnter Department: ";
    getline(cin, department);

    string emp_type;
    cout << "\nEnter Employee Type: ";
    getline(cin, emp_type);

    string band;
    cout << "\nEnter Band: ";
    getline(cin, band);

    string pf_numb;
    cout << "\nEnter PF_Details: ";
    getline(cin, pf_numb);

    string bank_details;
    cout << "\nEnter Bank Account: ";
    getline(cin, bank_details);

    float ctc__;
    cout << "\nEnter CTC: ";
    cin >> ctc__;
    
    cout << endl << endl;

    address *ad = new address(build_no, street, area, city, pin);

    employee *new_emp = new employee(name, gender, ad, location, department, emp_type, band, pf_numb, bank_details, ctc__);

    //auto new_emp_id = new_emp->get_id();

    this->emp_list.insert(make_pair(to_string(new_emp->get_id()), new_emp) );

}


// setters and getters code

string employer::get_company_name() {
    return company_name;
}

vector<string> employer::get_location() {
    return location;
}
vector<string> employer::get_bands() {
    return bands;
}
vector<string> employer::get_departments() {
    return departments;
}
map<string, employee*>& employer::get_emp_list() {
    return emp_list;
}   


