#include <iostream>
#include "employee.h"
#include "string"
#include <vector>


#ifndef EMPLOYER_H
#define EMPLOYER_H

using namespace std;

class employer {
    string company_name;
    vector<string> location;  //{"Bengaluru", "Kolkata", "Chennai", "Pune"};
    vector<string> bands;
    vector<string> departments;
    map<string, employee*> emp_list;

public:
    employer(const string& , const vector<string>& ,
     const vector<string>& , vector<string>& );

    // getters;

    string get_company_name();
    vector<string> get_location();
    vector<string> get_bands();
    vector<string> get_departments();
    map<string, employee*>& get_emp_list();

    // main functionalities
    void add_user(); //done
    void modify_user(const string& );
    void remove_employee(const string& );
    void search_employee(const string& ); //done
    void print_all();
    void generate_slip(const string& );
    void push_changes(string& , string& );
    void push_changes(float& , string& );

    void push_changes_CTC(float& value, const string& key);

    void push_changes_name(string& value, const string& key); 

    void push_changes_loc(string& value, const string& key);

    void push_changes_dept(string& value, const string& key);

    void push_changes_em_type(string& value, const string& key); 

    void push_changes_band(string& value, const string& key); 

    void push_changes_pf(string& value, const string& key);

    void push_changes_gender(string& value, const string& key);

    void push_changes_account(string& value, const string& key);

private:
    void print_emp_details(const string& );
};

#endif