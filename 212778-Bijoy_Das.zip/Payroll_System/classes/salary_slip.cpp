#include <iostream>
#include "salary_slip.h"
#include <iomanip>

using namespace std;

salary_slip::salary_slip(const float& ctc_, const float& mess_) : ctc {ctc_ * 100000}, mess_bill {mess_} {
    set_basic();
    set_vpp();
    set_pf();
    set_allowance();
    set_income_tax();
    set_gross_pay();
    set_net();
}
float salary_slip::get_mess_bill() {
    return mess_bill;
}

float salary_slip::get_basic() {
    return basic_salary;
}

float salary_slip::get_vpp() {
    return vpp;
}

float salary_slip::get_pf() {
    return pf;
}

float salary_slip::get_allowance() {
    return other_allow;
}

float salary_slip::get_income_tax() {
    return income_tax;
}

float salary_slip::get_gross_pay() {
    return gross_pay;
}

float salary_slip::get_net() {
    return net_pay;
}

void salary_slip::set_basic() {
    basic_salary = ctc * (60.0/100.0); 
}

void salary_slip::set_vpp() {
    vpp = ctc * (30.0/100.0);
}

void salary_slip::set_pf() {
    pf = ctc * (10.0/100.0);
}

void salary_slip::set_allowance() {
    other_allow = ctc * (5.0/100.0);
}

void salary_slip::set_income_tax() {
    if (ctc <= 5.0) {
        income_tax = 0;
    }

    else if (ctc > 5.0 && ctc <= 10.0) {
        income_tax = ctc * (5.0/100.0);
    }

    else if (ctc > 10.0 && ctc <= 15.0) {
        income_tax = ctc * (10.0/100.0); 
    }

    else if (ctc > 15.0 && ctc <= 20) {
        income_tax = ctc * (15.0/100.0);
    }

    else {
        income_tax = ctc * (20.0/100.0);
    } 
}

void salary_slip::set_gross_pay() {
    gross_pay = get_basic() + get_vpp() + get_pf() + get_allowance();
}

void salary_slip::set_net() {
    net_pay = get_gross_pay() - get_income_tax() - get_mess_bill();
}

void salary_slip::print_slip() {
    cout << endl;
    
    cout << "Basic Salary: " << basic_salary << endl;
    
    cout << "VPP: " << vpp << endl;
    
    cout << "PF_: " << pf << endl;
    
    cout << "Other_Allowances: " << other_allow << endl;
    
    cout << "Income tax: " << income_tax << endl;
    
    cout << "Gross Pay: " << gross_pay << endl;
    
    cout << "Net Pay: " << net_pay << endl;
}

