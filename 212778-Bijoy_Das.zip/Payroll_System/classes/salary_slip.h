#include <string>

#ifndef SALARY_SLIP_H
#define SALARY_SLIP_H

class salary_slip {
    float ctc;
    float basic_salary;
    float vpp;
    float pf;
    float other_allow;
    float income_tax;
    float gross_pay;
    float net_pay;
    float mess_bill;

private: 
    void set_basic();

    void set_vpp();

    void set_pf();

    void set_allowance();

    void set_income_tax();

    void set_gross_pay();

    void set_net();

public:
    salary_slip(const float& , const float& );
    float get_basic();
    float get_vpp();
    float get_pf();
    float get_allowance();
    float get_income_tax();
    float get_gross_pay();
    float get_mess_bill();
    float get_net();
    void print_slip();
};

#endif