#include "util_.h"

// constructor
util_::util_() {
    now = time(0);
    local_time = localtime(&now);
}


// generate date
std::string util_::get_date() {
    return to_string(local_time->tm_mon + 1) + "-" +
    to_string(local_time->tm_year + 1900);
}
