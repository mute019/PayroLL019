#include <string>
#include <ctime>
#include <iostream>

#ifndef UTIL__H
#define UTIL__h

using namespace std;

class util_ {
    std::time_t now;
    tm *local_time = nullptr;
public:
    util_();
    std::string get_date();
};

#endif
