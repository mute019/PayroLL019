#include "./classes/employer.h"
// #include "employee.cpp"
// #include "address.cpp"
// #include "salary_slip.cpp"
// #include "util_.cpp"
#include <vector>
#include <functional>
#include <string>
using namespace std;

int main() {
    string empler = "Sasken Technologies LTD.";
    vector<string> loc {"Bengaluru", "Kolkata", "Chennai", "Pune"};
    vector<string> bnds{"GT", "E1", "E2", "E3", "L1", "L2", "L3"};
    vector<string> depts {"SEC", "SatComm", "Devices", "RAN"};
    employer *emper = new employer(empler, loc, bnds, depts);  
    bool exit = false;

    while(!exit) {
        cout << "\n 1. Add User.";
        cout << "\n 2. Modify User.";
        cout << "\n 3. Remove User. ";
        cout << "\n 4. Search Employee. ";
        cout << "\n 5. Print All Employee. ";
        cout << "\n 6. Generate Salary Slip.";
        cout << "\n 7. Exit.";
        int chce;
        cout << "\n Enter Your Choice: ";
        cin >> chce;
        cin.ignore();
        switch (chce)
        {
        case 1 : {
            cout << "Enter Details!";
            emper->add_user();
            break;
        }

        case 2: {
            string em_id;
            cout << "\nEnter Employee ID to modify: ";
            cin >> em_id;

            emper->modify_user(em_id);
            break;
        }
        
        case 3: {

            string em_id;
            cout << "\nEnter Employee ID to remove: ";
            cin >> em_id;
            emper->remove_employee(em_id);
            break;
        }

        case 4: {

            string em_id;
            cout << "\nEnter Employee ID to search: ";
            cin >> em_id;
            emper->search_employee(em_id);
            break;
        }
        
        case 5: {

            cout << "\n All Employee Details: \n\n\n\n";
            emper->print_all();
            cout << "\n\n\n";
            break;
        }

        case 6: {

            string em_id;
            cout << "\nEnter Employee ID to Generate Slip: ";
            cin >> em_id;
            emper->generate_slip(em_id);
            break;
        }

        case 7:
            exit = true;
            break;

        default:
            cout << "\n\n\nWrong Choice!!\n\n";
            break;
        };
    }
    
    return 0;
}